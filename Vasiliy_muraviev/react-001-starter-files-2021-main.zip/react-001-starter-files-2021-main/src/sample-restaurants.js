// Наши рестораны
const restaurants = [
  {
    title: 'Hot Burger Тверская',
    url: 'hot-burger-tverskaya',
    id: 1
  },

  {
    title: 'Hot Burger Маросейка',
    url: 'hot-burger-maroseyka',
    id: 2
  },
  {
    title: 'Hot Burger Петровка',
    url: 'hot-burger-petrovka',
    id: 3
  }
];

export default restaurants;
